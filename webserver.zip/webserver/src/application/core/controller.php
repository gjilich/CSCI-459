<?php
class Controller
{
    function __construct() {
        session_start();
    }
}