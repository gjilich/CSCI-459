<?php
class Hash
{
    public static function Create($password)
    {
        $options = [
            "cost" => 10
        ];
        return password_hash($password, PASSWORD_BCRYPT, $options);
    }

    public static function Verify($password, $hash)
    {
        return password_verify($password, $hash);
    }
}

?>
