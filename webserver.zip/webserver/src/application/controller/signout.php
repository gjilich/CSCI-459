<?php

class SignOut extends Controller
{
    public function index() {
        if(isset($_SESSION["username"])) {
            unset($_SESSION["username"]);
            unset($_SESSION["user_id"]);
            header('location: ' . URL . 'signin');
        }
    }
}