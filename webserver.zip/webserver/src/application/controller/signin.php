<?php
class SignIn extends Controller {
    public function index() {
        if(isset($_SESSION["username"], $_SESSION["user_id"])) {
            header('location: ' . URL . 'records');
            return;
        }
        if(isset($_POST["username"], $_POST["password"])) {
            require APP . 'core/database.php';
            require APP . 'model/userdb.php';
            $model = new UserDB(Database::openConnection());

            if($user = $model->loginUser($_POST["username"], $_POST["password"])) {
                $_SESSION["user_id"] = $user["id"];
                $_SESSION["username"] = $user["username"];
                $output = array("success" => true);
                echo json_encode($output);
            }
            else {
                $output = array("success" => false, "message" => "Incorrent username/password combination.");
                echo json_encode($output);
            }
        }
        else {
            require APP . 'view/signin/index.php';
        }
    }
}