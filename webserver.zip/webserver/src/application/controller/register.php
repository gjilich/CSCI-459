<?php
class Register extends Controller {
    public function index()
    {
        if(isset($_SESSION["username"])) {
            header('location: ' . URL . 'records');
            return;
        }
        if(isset($_POST["username"], $_POST["email"], $_POST["password"], $_POST["confirmPassword"])) {
            require APP . 'core/database.php';
            require APP . 'model/userdb.php';
            $model = new UserDB(Database::openConnection());
            if($model->isExist($_POST["username"])) {
                $output = array("success" => false, "message" => "There is already a user with that username.");
                echo json_encode($output);
                return;
            }
            if($user = $model->getUser($_POST["email"]))
            {
                $output = array("success" => false, "message" => "There is already a user with that email.");
                echo json_encode($output);
                return;
            }

            $model->addUser($_POST["username"], $_POST["password"], $_POST["email"]);
            $output = array("success" => true);
            echo json_encode($output);
        }
        else {
            require APP . 'view/register/index.php';
        }
    }


}