<?php
class Records extends Controller {
    public function index()
    {
       if(isset($_SESSION["username"], $_SESSION["user_id"])) {
            require APP . 'core/database.php';
            require APP . 'model/record.php';
            require APP . 'model/recorddb.php';
            $model = new RecordDB(Database::openConnection());
            $records = array();
            $results = $model->getRecords($_SESSION["user_id"]);
            foreach ($results as $result) {
                $record = new Record();
                $record->id = $result["id"];
                $record->userProfile = $result["user_uid"];
                $record->amount = $result["amount"];
                $record->paidIn = $result["paid_in"];
                $record->email = $result["user_email"];
                $record->date = $result["date"];
                $record->im = $result["user_im"];
                $records[] = $record;
            }
            require APP . 'view/records/index.php';
        }
        else {
            header('location: ' . URL . 'signin');
        }
    }

   public function add() {
       if(isset($_SESSION["username"], $_SESSION["user_id"])) {
           if(isset($_POST["uid"], $_POST["amount"], $_POST["paidin"], $_POST["email"], $_POST["im"])) {
               require APP . 'core/database.php';
               require APP . 'model/recorddb.php';
               $model = new RecordDB(Database::openConnection());
               $model->addRecord($_SESSION["user_id"], $_POST["uid"], $_POST["amount"], $_POST["paidin"], $_POST["email"], $_POST["im"]);
               $output = array("success" => true);
               echo json_encode($output);
           }
           else {
               require APP . 'view/records/add.php';
           }
       }
       else {
           header('location: ' . URL . 'signin');
       }
   }

    public function delete($id) {
        if(isset($_SESSION["username"], $_SESSION["user_id"])) {
            if(isset($id)) {
                require APP . 'core/database.php';
                require APP . 'model/recorddb.php';
                $model = new RecordDB(Database::openConnection());
                $model->deleteRecord($id);
            }
            header('location: ' . URL . 'records');
        }
    }
}