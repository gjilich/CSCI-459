<!doctype html>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Trading Records - Records</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <!-- Styles -->
    <link href="<?php echo URL; ?>css/panel.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">
</head>
<body>
    <div class="container">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
            <h1 class="h2">Add a new record</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <a href="../records"><button class="btn btn-sm btn-outline-secondary">Go back</button></a>
            </div>
        </div>
        <form id="form-record-add" class="form-inline">
            <label class="sr-only" for="inputUID">Profile Link / UID</label>
            <input type="text" name="uid" class="form-control mb-2 mr-sm-2" id="inputUID" placeholder="Profile Link / UID">

            <label class="sr-only" for="inputAmount">Amount</label>
            <input type="text" name="amount" class="form-control mb-2 mr-sm-2" id="inputAmount" placeholder="Amount">

            <label class="sr-only" for="inputPaidIn">Paid In</label>
            <input type="text" name="paidin" class="form-control mb-2 mr-sm-2" id="inputPaidIn" placeholder="Paid In">

            <label class="sr-only" for="inputEmail">Email</label>
            <input type="text" name="email" class="form-control mb-2 mr-sm-2" id="inputEmail" placeholder="Email">

            <label class="sr-only" for="inputIM">IM</label>
            <input type="text" name="im" class="form-control mb-2 mr-sm-2" id="inputIM" placeholder="IM">

            <button type="submit" class="btn btn-primary mb-2">Submit</button>
        </form>
    </div>
</body>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<!-- Popper.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- Scripts -->
<script src="<?php echo URL; ?>js/script.js"></script>
</body></html>