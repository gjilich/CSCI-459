<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Trading Records - Register</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <!-- Styles -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="text-center">
<div class="container">
    <h1 class="h1 mb-4 font-weight-normal">Trading Records</h1>
    <form id="form-register">
        <h1 class="h1 mb-3 font-weight-light">Register</h1>
        <label for="inputUsername" class="sr-only">Username</label>
        <input type="text" name="username" id="inputUsername" class="form-control" placeholder="Username" autofocus="">
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address">
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password">
        <label for="inputConfirmPassword" class="sr-only">Confirm Password</label>
        <input type="password" name="confirmPassword" id="inputConfirmPassword" class="form-control" placeholder="Confirm Password">
        <button class="btn btn-lg btn-primary btn-block" type="submit">Register</button>
        <div class="alert mt-2" style="display: none;" role="alert"" role="alert">
    </form>
    <p>
        Already have an account? <a href="signin">Sign in</a>
    </p>
</div>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<!-- Popper.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- Scripts -->
<script src="js/script.js"></script>
</body>
</html>