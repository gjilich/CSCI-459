<?php
class RecordDB
{
    function __construct($db) {
        try {
            $this->db = $db;
        } catch (PDOException $e) {
            exit('Database connection could not be established.');
        }
    }

    function addRecord($user_id, $uid, $amount, $paidin, $email, $im) {
        $sql = "INSERT INTO records (user_id, user_uid, amount, paid_in, user_email, user_im) VALUES (:id, :user_id, :amount, :paid_in, :user_email, :user_im)";
        $query = $this->db->prepare($sql);
        $parameters = array(':id' => $user_id, ':user_id' => $uid, ':amount' => $amount, ':paid_in' => $paidin, ':user_email' => $email, ':user_im' => $im);
        $query->execute($parameters);
    }

    function deleteRecord($id) {
        $sql = "DELETE FROM records WHERE id = :id";
        $query = $this->db->prepare($sql);
        $parameters = array(':id' => $id);
        $query->execute($parameters);
    }

    function getRecords($user_id) {
        $sql = "SELECT id, user_uid, amount, paid_in, user_email, date, user_im FROM records WHERE user_id = :user_id";
        $query = $this->db->prepare($sql);
        $parameters = array(":user_id" => $user_id);
        $query->execute($parameters);
        return $query->fetchAll();
    }
}