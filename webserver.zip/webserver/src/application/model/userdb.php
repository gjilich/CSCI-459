<?php
require APP . 'core/hash.php';

class UserDB
{
    private $db;

    /**
     * userdb constructor.
     * @param $db
     */
    function __construct($db) {
        try {
            $this->db = $db;
        } catch (PDOException $e) {
            exit('Database connection could not be established.');
        }
    }

    /**
     * @param $username
     * @return bool
     */
    public function isExist($username) {
        $sql = "SELECT COUNT(1) as count FROM users WHERE  username = :username OR email = :username";
        $query = $this->db->prepare($sql);
        $parameters = array(':username' => $username);
        $query->execute($parameters);
        return $query->fetch()["count"] == 1;
    }

    /**
     * @param $username
     * @param $password
     * @param $email
     */
    public function addUser($username, $password, $email) {
        $sql = "INSERT INTO users (username, password, email) VALUES (:username, :password, :email)";
        $query = $this->db->prepare($sql);
        $parameters = array(':username' => $username, ':password' => Hash::Create($password), ':email' => $email);
        $query->execute($parameters);
    }

    /**
     * @param $username
     * @return mixed
     */
    public function getUser($username) {
        $sql = "SELECT id, username, password, email FROM users WHERE username = :username OR email = :username";
        $query = $this->db->prepare($sql);
        $parameters = array(":username" => $username);
        $query->execute($parameters);
        return $query->fetch();
    }

    public function loginUser($username, $password) {
        $user = $this->getUser($username);
        if(Hash::Verify($password, $user["password"])) {
            return $user;
        }
        else
            return false;
    }
}