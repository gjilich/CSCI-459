<?php
class Record
{
    public $id;
    public $userProfile;
    public $amount;
    public $paidIn;
    public $email;
    public $im;
    public $date;
}