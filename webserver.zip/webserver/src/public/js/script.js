// Sign In
$("#form-signin").submit((event) => {
    event.preventDefault();
    let form = $("#form-signin");
    let username = form.find("#inputEmail").val().toLowerCase();
    let password = form.find("#inputPassword").val();
    let alert = $(".alert");

    if(username.length == 0 || isWhiteSpace(username)) {
        alert.text("Please enter a username or email.");
        alert.addClass("alert-danger")
            .show().fadeOut(3000, () => alert.removeClass("alert-danger"));
        return;
    }
    if(!isValidPassword(password)) {
        alert.text("Please enter a valid password.");
        alert.addClass("alert-danger")
            .show().fadeOut(3000, () => alert.removeClass("alert-danger"));
        return;
    }
    form.find("button[type=submit]").prop("disabled", true);

   $.ajax("signin", {
        method: "POST",
        data: {username: username,
                password: password},
        success: (result) => {
            console.log(result);
            let resultJSON = $.parseJSON(result);
            if (resultJSON.success) {
                alert.html('Success! You\'ll be <a href="records">redirected automatically to the panel.</a>');
                setTimeout(() => window.location.replace("records"), 3000);
                alert.addClass("alert-success").show();
            }
            else {
                alert.text(`${resultJSON.message}`);
                alert.addClass("alert-danger")
                    .show().fadeOut(3000, () => alert.removeClass("alert-danger"));
            }
            $("button[type=submit]").prop("disabled", false);
        }
    })
});

// Register
$("#form-register").submit((event) => {
    event.preventDefault();
    let form = $("#form-register");
    let username = form.find("#inputUsername").val().toLowerCase();
    let email = form.find("#inputEmail").val().toLowerCase();
    let password = form.find("#inputPassword").val();
    let confirmPassword = form.find("#inputConfirmPassword").val();
    let alert = $(".alert");

    if(!isAlphaNumeric((username)) || !(username.length >= 4 && username.length <= 64)) {
        alert.text("Please enter a valid username, between 4 and 64 characters, only letters and numbers.");
        alert.addClass("alert-danger")
            .show().fadeOut(3000, () => alert.removeClass("alert-danger"));
        return;
    }
    if(!isValidEmail((email))) {
        alert.text("Please enter a valid email.");
        alert.addClass("alert-danger")
            .show().fadeOut(3000, () => alert.removeClass("alert-danger"));
        return;
    }
    if(!isValidPassword(password)) {
        alert.text("Please enter a valid password.");
        alert.addClass("alert-danger")
            .show().fadeOut(3000, () => alert.removeClass("alert-danger"));
        return;
    }
    if(password != confirmPassword) {
        alert.text("Your password and confirmation password don't match.");
        alert.addClass("alert-danger")
            .show().fadeOut(3000, () => alert.removeClass("alert-danger"));
        return;
    }
    form.find("button[type=submit]").prop("disabled", true);

    $.ajax("register", {
        method: "POST",
        data: {username: username,
                email: email,
                password: password,
                confirmPassword: confirmPassword},
        success: (result) => {
            let resultJSON = $.parseJSON(result);
            if (resultJSON.success) {
                alert.html('Success! You\'ll be <a href="signin">redirected automatically to the login page.</a>');
                setTimeout(() => window.location.replace("signin"), 3000);
                alert.addClass("alert-success").show();
            }
            else {
                alert.text(`${resultJSON.message}`);
                alert.addClass("alert-danger")
                    .show().fadeOut(3000, () => alert.removeClass("alert-danger"));
            }
            $("button[type=submit]").prop("disabled", false);
        }
    })
});

function isValidPassword(password) {
    if(password.length < 8)
        return false;
    if(isWhiteSpace(password[0]) || isWhiteSpace(password[password.length - 1]))
        return false;

    for(let i = 0; i < password.length; i++) {
        if (!(password[i].charCodeAt(0) >= 32 && password[i].charCodeAt(0) <= 126))
        {
            return false;
        }
    }

    return true;
}

function isWhiteSpace(text) {
    return /\s/.test(text);
}

function isValidEmail(email) {
    return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email);
}

function isAlphaNumeric(text) {
    return /^[a-z0-9]+$/.test(text);
}

// Add Record
$("#form-record-add").submit((event) => {
    event.preventDefault();
    let form = $("#form-record-add");
    form.find("button[type=submit]").prop("disabled", true);
    $.ajax("add", {
        method: "POST",
        data: form.serialize(),
        success: (result) => {
            console.log(result);
            let resultJSON = $.parseJSON(result);
            if (resultJSON.success) {
                window.location.replace("../");
            }
            $("button[type=submit]").prop("disabled", false);
        }
    })
});